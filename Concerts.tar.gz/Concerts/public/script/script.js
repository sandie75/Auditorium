//Btn Delete
const deleteConfirm = document.querySelectorAll("[data-name=deleteConfirm]");

deleteConfirm.forEach(function(linkDelete){
    linkDelete.addEventListener('click', function(event){
        event.preventDefault();
        if (confirm("Vous êtes sûr?")){
            location.href = linkDelete.getAttribute("href");
        }
        console.log(linkDelete);
    })
})

const hamburger = document.querySelector(".hamburger");
const navMenu = document.querySelector(".nav-menu");

hamburger.addEventListener("click", ()=>{
    hamburger.classList.toggle("active");
    navMenu.classList.toggle("active");
})
document.querySelectorAll("nav-link").forEach(n => n.addEventListener("click", ()=> {
    hamburger.classList.remove("active");
    NavMenu.classList.remove("active");
}))