<footer>        
        <div class="footer">
            <div class="col1">
                <h3>Contact</h3>
                <p>25 rue Raoul Warocqué</p><p>35000 La Louvière.</p>
            </div> 
            <div class="col2">
                <h3>Liens utiles</h3>
                <a href="#">À propos</a>
                <a href="includes/core/views/view_contact.php">Nous contacter</a>
                <a href="#">Recrutement</a>
                <a href="#">Mentions légales</a>
            </div>
            <div class="col3">
                <h3>Suivez-nous :</h3>
                <a href="#"><img class="icon" src="public/img/icons/facebook.png" alt="facebook"/></a>
                <a href="#"><img class="icon" src="public/img/icons/instagram.png" alt="instagram"/></a>
                <a href="#"><img class="icon" src="public/img/icons/twitter.png" alt="twitter"/></a>
                <a href="#"><img class="icon" src="public/img/icons/youtube.png" alt="youtube"/></a>
            </div>        
        </div>
</footer>            
        