<header>
    <?php
        if (isset($_SESSION['login']) && $_SESSION['login'] != ''){
                echo "<div class='connexion_form' id='deconnecter'><a href='index.php?page=userform&action=logout'>Me déconnecter</a></div>";
            }
            else {
                echo'<div class="connexion_form">
                        <form id="connexion_form_container" action="index.php?page=userform&action=login" method="post">
                            
                            <div class="connexion_entree">
                                <label for="login">login</label>
                                <input type="text" name="login" id="login" required>
                            </div>
                            
                            <div class="connexion_entree">
                                <label for="password">Mot de passe</label>
                                <input type="password" name="password" id="password" required>
                            </div>
                            
                            <div>
                                <button class="connect-btn" type="submit">Se connecter</button>
                            </div>
                            
                        </form>
                    </div>';
            }
    ?>
    
        
        <nav class="navbar">
            <a href="index.php"><h2 class="nav-title">Auditorium St-Siméon</h2></a>
            <ul class="nav-menu">
                <li class="nav-item"><a class="nav-link" href="index.php?page=agenda">Agenda</a></li>
                <li class="nav-item"><a class="nav-link" href="index.php?page=artistes&action=list">Artistes</a></li>
                <li class="nav-item"><a class="nav-link" href="index.php?page=reservations">Réservations</a></li>
                <li class="nav-item"><a class="nav-link" href="index.php?page=acces">Plan d'accès</a></li>
            </ul>
            <div class="hamburger">
                <span class="bar"></span>
                <span class="bar"></span>
                <span class="bar"></span>
            </div>
        </nav>
    
</header>