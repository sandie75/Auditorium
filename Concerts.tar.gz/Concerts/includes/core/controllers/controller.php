<?php
    require_once("includes/core/views/view_homepage.php");