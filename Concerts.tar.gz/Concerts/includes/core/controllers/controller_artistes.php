<?php
    require_once('includes/core/models/dao/dao_artiste.php');
    switch($action){
        case 'list':{
            $allArtists = getAllArtists();
            require_once("includes/core/views/view_artistes.php");
            break;
        }
        case 'add':{
            require_once("includes/core/models/dao/dao_artiste.php");
            if(empty($_POST)){
                //j'arrive sur le formulaire vierge
                $artist = new Artiste();
            }
            else{
                // récupérer le chemin temporaire du fichier uploadé
                $tmpPath = $_FILES['chPicture']['tmp_name'];
                $destPath = 'public/img/artistes/';
                $destFileName = $_FILES['chPicture']['name'];

                $fullDestName = $destPath.$destFileName;

                if (!move_uploaded_file($tmpPath, $fullDestName)){
                    die("Tu as oublié l'image !");
                }
                //le formulaire est validé, j'ai cliqué sur submit
                $artist = new Artiste(
                    
                    htmlspecialchars($_POST["chName"]),
                    htmlspecialchars($_POST["chDescription"]),
                    $fullDestName,
                    
                    htmlspecialchars($_POST["chInstrument"])
                    );
                    
                    if(insertArtiste($artist)){
                        header('Location: ?page=artistes&action=list');
                    }
                    else{
                        $message="Erreur d'enregistrement";
                    }
            }
            require_once("includes/core/views/form_artist.php");
            break;
        }
        case 'edit':{
            require_once("includes/core/models/dao/dao_artiste.php");
            $id_artist=$_GET["id"]??0;
            $artist=getArtistById($id_artist);
            if(!empty($_POST)){
                //le formulaire est validé, j'ai cliqué sur submit
                    $artist->setName($_POST["chName"]);
                    $artist->setDescription($_POST["chDescription"]);
                    $artist->setPicture($_POST["chPicture"]);
                    $artist->setInstrument($_POST["chInstrument"]);
                    
                    if(editArtiste($artist)){
                        header('Location: ?page=artistes&action=list');
                    }
                    else{
                        $message="Erreur d'enregistrement";
                    }
            }
            require_once("includes/core/views/form_artist.php");
            break;
        }
        case 'delete':{
            require_once("includes/core/models/dao/dao_artiste.php");
            $id_artist=$_GET["id"]??0;
            
                    if(deleteArtiste($id_artist)){
                        $message="Suppression confirmée";
                        header('Location: ?page=artistes&action=list');
                    }
                    else{
                        $message="Erreur d'enregistrement";
                    }
            }
            require_once("includes/core/views/form_artist.php");
            break;
        default:{
            require_once ("includes/core/controller_error.php");
        }
    }
    
    
    
    
    