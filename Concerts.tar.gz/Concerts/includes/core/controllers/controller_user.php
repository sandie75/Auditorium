<?php
    switch ($action){
        case 'login':{
                require_once "includes/core/models/dao/dao_user.php";
                if (!empty($_POST)){
                    $loginSaisi = $_POST['login'];
                    $mdpSaisi = $_POST['password'];
    
                    if (userExists($loginSaisi)){
                        print('Mon login existe :-)');
                        if (checkAuth($loginSaisi, $mdpSaisi)){
                            $_SESSION['login'] = $loginSaisi;
                            $_SESSION['iduser'] = getUserIdByLogin($loginSaisi);
                            header('Location: index.php');
                        }else{
                            $message = "Mauvaises informations d'identification !";
                        }
                    }else{
                        $message = "Cet utilisateur n'existe pas !";
                    }
                }
                break;
            }
    
            case 'logout':{
                if (isset($_SESSION['login'])){
                    unset($_SESSION['login']);
                }
                header('Location: index.php');
                break;
            }
    
            default:{
    
            }
    }

?>