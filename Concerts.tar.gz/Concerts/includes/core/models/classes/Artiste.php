<?php

	class Artiste{
		private int $idArtiste;
		private string $name, $description, $picture, $instrument;
                    
		

		public function __construct(string $name = '', string $description = '', string $picture = '',
			string $instrument = ''){
                $this->idArtiste = 0;
				$this->name = $name;
				$this->description = $description;
				$this->picture = $picture;
				$this->instrument = $instrument;
		}

		public function getId(): int{
			return $this->idArtiste;
		}

		public function setId(int $idArtiste): void{
			$this->idArtiste = $idArtiste;
		}
        public function getName(): string{
			return $this->name;
		}
		public function setName(string $name): void{
			$this->name = $name;
		}
        public function getDescription(): string{
			return $this->description;
		}
		public function setDescription(string $description): void{
			$this->description = $description;
		}
		public function getPicture(): string{
			return $this->picture;
		}
		public function setPicture(string $picture): void{
			$this->picture = $picture;
		}
        public function getInstrument(): string{
			return $this->instrument;
		}
		public function setInstrument(string $instrument): void{
			$this->instrument = $instrument;
		}
}
