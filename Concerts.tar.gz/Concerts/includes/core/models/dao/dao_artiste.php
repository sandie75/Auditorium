<?php
    require_once('includes/core/models/bdd.php');
    require_once('includes/core/models/classes/Artiste.php');
    
    
    function getAllArtists(){
        $conn = getConnexion();

        $SQLQuery = "SELECT * FROM artistes ORDER BY name ASC";

        $SQLStmt = $conn->prepare($SQLQuery);
        $SQLStmt->execute();

        $listeArtistes = array();

        while ($SQLRow = $SQLStmt->fetch(PDO::FETCH_ASSOC)){
            $unArtiste = new Artiste($SQLRow['name'], $SQLRow['description'], $SQLRow['picture'], $SQLRow['instrument']);

            $unArtiste->setId($SQLRow['id_artistes']);
            $listeArtistes[] = $unArtiste;
        }

        $SQLStmt->closeCursor();
        return $listeArtistes;
    }
    
    function getArtistById($id_artistes){
        $conn = getConnexion();

        $SQLQuery = "SELECT id_artistes,name,description,picture, instrument FROM artistes WHERE id_artistes = :id_artistes";

        $SQLStmt = $conn->prepare($SQLQuery);
        $SQLStmt->bindValue(':id_artistes', $id_artistes, PDO::PARAM_INT);
        $SQLStmt->execute();

        $SQLRow = $SQLStmt->fetch(PDO::FETCH_ASSOC);
        $artist = new Artiste($SQLRow['name'],$SQLRow['description'], $SQLRow['picture'], $SQLRow['instrument']);
        $artist->setId($SQLRow['id_artistes']);

        $SQLStmt->closeCursor();
        return $artist;
    }
    
    function insertArtiste(Artiste $newArtiste): bool {
        $conn = getConnexion();

        $SQLQuery = "INSERT INTO artistes(name, description, picture, instrument)
        VALUES (:name, :description, :picture, :instrument)";

        $SQLStmt = $conn->prepare($SQLQuery);
        $SQLStmt->bindValue(':name', $newArtiste->getName(), PDO::PARAM_STR);
        $SQLStmt->bindValue(':description', $newArtiste->getDescription(), PDO::PARAM_STR);
        $SQLStmt->bindValue(':picture', $newArtiste->getPicture(), PDO::PARAM_STR);
        $SQLStmt->bindValue(':instrument', $newArtiste->getInstrument(), PDO::PARAM_STR);

        if (!$SQLStmt->execute()){
            return false;
        }else{
            return true;
        }
    }
    
     function editArtiste(Artiste $editArtiste) : bool{
        $conn = getConnexion();

        $SQLQuery = "UPDATE artistes 
                    SET name = :name, description = :description, picture = :picture, instrument = :instrument
                    WHERE id_artistes = :id_artistes";

        $SQLStmt = $conn->prepare($SQLQuery);
        $SQLStmt->bindValue(':id_artistes', $editArtiste->getId(), PDO::PARAM_INT);
        $SQLStmt->bindValue(':name', $editArtiste->getName(), PDO::PARAM_STR);
        $SQLStmt->bindValue(':description', $editArtiste->getDescription(), PDO::PARAM_STR);
        $SQLStmt->bindValue(':picture', $editArtiste->getPicture(), PDO::PARAM_STR);
        $SQLStmt->bindValue(':instrument', $editArtiste->getInstrument(), PDO::PARAM_STR);
        return $SQLStmt->execute();
    }
    
    function deleteArtiste(int $deleteArtiste) : bool{
        $conn = getConnexion();

        $SQLQuery = "DELETE FROM artistes WHERE id_artistes = :id_artistes";
        $SQLStmt = $conn->prepare($SQLQuery);
        $SQLStmt->bindValue(':id_artistes', $deleteArtiste, PDO::PARAM_INT);

        return $SQLStmt->execute();
    }       
           
           
           
           
           
            
            