<?php
    require_once('includes/core/models/bdd.php');
    require_once('includes/core/models/classes/Concert.php');
    require_once('includes/core/models/dao/dao_artiste.php');
    
    function getConcerts(){
        $conn = getConnexion();

        $SQLQuery = "SELECT * FROM concert";

        $SQLStmt = $conn->prepare($SQLQuery);
        $SQLStmt->execute();

        $concertsList = array();

        while ($SQLRow = $SQLStmt->fetch(PDO::FETCH_ASSOC)){
            $concert = new Concert($SQLRow['date'], $SQLRow['time'], $SQLRow['libelle'], 
                       getArtistById($SQLRow['id_artistes']), $SQLRow['concert_description'], $SQLRow['concert_pic'], 
                       $SQLRow['sold_out']);

            $concert->setId($SQLRow['id_artistes']);
            $concertsList[] = $concert;
        }
        $SQLStmt->closeCursor();
        return $concertsList;
    }
            