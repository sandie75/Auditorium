<?php     
            /*//connexion
            $server = 'db.3wa.io';
            $port = 3306;
            $sbdname = 'sandieemonts_concert';
            $username = 'sandieemonts';
            $password = '430960e1c4c153edc5b3f4bb023331fc';
            
            //construction de la chaine de connection: Data Source Name
            $dsn = "mysql:host=$server;port=$port;dbname=$sbdname;charset=utf8";
            try{
                $conn = new PDO($dsn,$username,$password);
            }catch(PDOException $ex){
                print('impossible de se connecter');
                die('au revoir');
            }    
            //execution de la requete
            
            $SQLResult = $conn->query("SELECT * FROM concert");
            //exploitation des resultats
            print('<pre>');
            
            print('</pre>');
            $concerts = $SQLResult->fetchAll(PDO::FETCH_ASSOC);
            
             //liberation des ressources 
            $SQLResult->closeCursor*/
              
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>agenda</title>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;0,700;1,300;1,400&family=Poppins:ital,wght@0,200;0,400;0,500;0,700;1,100&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,300;0,500;0,700;1,400;1,600&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="public/style/style.css">
    </head>

    <body>
        <?php 
        require_once('includes/partials/header.php');?>
        <main>
            <div class="banniere">
                <img class="imagebanniere" src="public/img/natachasquare.png" alt="piano player"/>
                <img class="imagebanniere" src="public/img/lislevand-playing.jpg" alt="lute player"/>
                <img class="imagebanniere" src="public/img/larry3.jpg" alt="dancer"/>
                <img class="imagebanniere" src="public/img/bourne4.jpg" alt="dancers"/>
                <img class="imagebanniere" src="public/img/cooper5.jpg" alt="dancer"/>
                <img class="imagebanniere" src="public/img/savallsquare.jpg" alt="viola player"/>
                <img class="imagebanniere" src="public/img/hamon-playing3.jpg" alt="flute-player"/>
                <img class="imagebanniere" src="public/img/orlinski-singing.jpg" alt="singer"/>
                <img class="imagebanniere" src="public/img/laurent9.jpg" alt="dancer"/>
                <img class="imagebanniere" src="public/img/maxwell10.jpg" alt="quartet"/>
                <img class="imagebanniere" src="public/img/alastair11.jpg" alt="pianist"/>
                <img class="imagebanniere" src="public/img/orlinski-singing2.jpg" alt="sheet music"/>
                
            </div>    
            <h1>L'agenda</h1>
            <div class="agenda-container">
                <?php
                    foreach($concerts as $concert){
                        echo"<div class='date'>
                                <div class='concert-date'>
                                    <h2 class='day'>".$concert->getDate()."</h2>
                                    <h2 class='time'>".$concert->getTime()."</h2>
                                    <h3 class='artist-agenda'>".$concert->getArtist()->getName()."</h3>
                                    <h3 class='libelle'>".$concert->getLibelle()."</h3>
                                </div>
                                <div class='concert-description'>
                                    <p>".$concert->getConcertDescription()."</p>
                                </div>
                                <div class='concert-pic'>
                                    <img class='concert-picture' src='".$concert->getConcertPic()."'/>
                                </div>
                            </div>";
                    }
                ?>
            </div>
            
        </main>
        
        <?php require_once('includes/partials/footer.php');?>
        
        <script src="public/script/script.js"></script>
    </body>
</html>