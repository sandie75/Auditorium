<?php
    require_once("includes/core/models/dao/dao_artiste.php");
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>formulaire artiste</title>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;0,700;1,300;1,400&family=Poppins:ital,wght@0,200;0,400;0,500;0,700;1,100&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,300;0,500;0,700;1,400;1,600&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="public/style/style.css">

    </head>
    <body>
        
        <?php
            require_once('includes/partials/header.php');
        ?>
        <main class="form-artist-main">
            <div class="form-artist-container">
                <form class="form-artist" action="" method="POST" enctype="multipart/form-data">
                    <h2>Ajouter un artiste</h2>
                    <div class="submit-entree">
                        <label for="champName">Nom </label>
                        <input type="text" name="chName" id="champName" value="<?= $artist->getName() ?>" required/>
                    </div>
                    <div class="submit-entree">
                        <label for="champDescription">Description </label>
                        <textarea type="text" name="chDescription" id="champDescription" rows="10" value="<?= $artist->getDescription() ?>"></textarea>
                    </div>
                    <div class="submit-entree">
                        <label for="chInstrument">Instrument </label>
                        <input type="text" name="chInstrument" id="chInstrument" value="<?= $artist->getInstrument() ?>" required/>
                    </div>
                    <div class="submit-entree">
                        <label for="champPicture">Image </label>
                        <input type="file" name="chPicture" id="champPicture" value="<?= $artist->getPicture() ?>"/>
                    </div>
                    <button class="form-btn" id="reinitialiser" type="submit">Réinitialiser</button>
                    <button class="form-btn" id="valider" type="reset">Valider</button>
                </form>
            </div>
        </main>
        <?php
            
            require_once('includes/partials/footer.php');
        ?>
        
        <script src="public/script/script.js"></script>
    </body>
</html>