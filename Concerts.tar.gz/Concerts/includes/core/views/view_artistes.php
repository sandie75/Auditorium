<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>artistes</title>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;0,700;1,300;1,400&family=Poppins:ital,wght@0,200;0,400;0,500;0,700;1,100&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,300;0,500;0,700;1,400;1,600&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="public/style/style.css">
    </head>
    <body>
        <?php 
        
        require_once('includes/partials/header.php');?>
        <main class="artists-main">
            <h1>Artistes</h1>
            <div class="form_acces">
                <?php
                    if (isset($_SESSION['login'])) {
                    print('<div id="ajouter-container"><a class="ajouter" href="index.php?page=artistes&action=add">Ajouter</a></div>');
                    }
                ?>
                
            </div>
            <div class="artist-container">
                <?php
                    foreach($allArtists as $artist) {
                        echo"<div class='artist'>
                                <div>
                                    <img class='portrait' src='public/img/artistes/".$artist->getPicture()."'/>
                                </div>
                                <div class='artist-description'>
                                    <h3>".$artist->getName()."</h3>
                                    <p>".$artist->getDescription()."</p>";
                                    if (isset($_SESSION['login'])) {
                                        print('<div id="editer-container"><a class="editer" href="index.php?page=artistes&action=edit&id='.$artist->getId().'">Editer</a></div>');
                                        print('<div id="supprimer-container"><a class="supprimer" data-name=deleteConfirm href="index.php?page=artistes&action=delete&id='.$artist->getId().'">Supprimer</a></div>');
                                    }
                                echo"</div>
                            </div>";
                    }          
               ?>
            </div>
        </main>
        <?php require_once('includes/partials/footer.php');?>
        <script src="public/script/script.js"></script>
    </body>
</html>