<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Page d'accueil</title>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;0,700;1,300;1,400&family=Poppins:ital,wght@0,200;0,400;0,500;0,700;1,100&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,300;0,500;0,700;1,400;1,600&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="public/style/style.css">

    </head>
    <body>
       <header>
      <!--------------------------------------------header--------------------------------------------->
      
        <div class="headertop">
        </div>
        <div>
            <?php
                require_once('includes/partials/header.php');
            ?>
        </div>
        
        </header>
        
        <!--------------------------------------------Main---------------------------------------->
        
        <main class="homepage-main">
            <img src="public/img/homepage-img/piano.jpg" alt="photo-piano" class="photo-opera"/>
            <h1>Auditorium St-Siméon</h1>
            <div class="homepage-text">
                <p>Lorem ipsum dolor sit amet consectetur adipiscing elit semper nullam, elementum eros curabitur sagittis pretium scelerisque at dictumst, nostra lacus ante proin quisque nisl sodales natoque. Aliquam viverra laoreet nunc eros porttitor placerat consequat tincidunt lobortis, netus taciti nisi condimentum tempus dapibus malesuada phasellus porta, lacinia platea himenaeos sodales ornare potenti sollicitudin quisque. Cum eros aliquet nisl semper fusce cubilia vitae orci porta, varius pulvinar massa sodales commodo curae nostra himenaeos, imperdiet curabitur pretium laoreet dui accumsan volutpat placerat.</p>
            </div>    
            <div class="homepage-gallery">
                <div class="img-container">
                    <h3>Visites</h3>
                    <img src="public/img/opera.jpg" alt="photo-concerthall" class="homepage-img">
                </div>
                <div class="img-container">
                    <h3>Ateliers</h3>
                    <img src="public/img/homepage-img/festival.jpg" alt="photo-festival" class="homepage-img">
                </div>
                <div class="img-container">
                    <h3>Masterclass</h3>
                    <img src="public/img/homepage-img/trio.jpeg" alt="photo-trio" class="homepage-img">
                </div>
                <div class="img-container">
                    <h3>Boutique</h3>
                    <img src="public/img/homepage-img/partition.jpg" alt="photo-partition" class="homepage-img">
                </div>
                <div class="img-container">
                    <h3>Livre d'or</h3>
                    <img src="public/img/homepage-img/violon.jpg" alt="photo-violon" class="homepage-img">
                </div>
                <div class="img-container">
                    <h3>Évènements</h3>
                    <img src="public/img/homepage-img/rattle.jpg" alt="photo-rattle" class="homepage-img">
                </div>
            </div>
        </main>
        
        <!--------------------------------------------footer--------------------------------------------------->
        
        <?php
            
            require_once('includes/partials/footer.php');
        ?>
        <script src="public/script/script.js"></script>
    </body>
</html>